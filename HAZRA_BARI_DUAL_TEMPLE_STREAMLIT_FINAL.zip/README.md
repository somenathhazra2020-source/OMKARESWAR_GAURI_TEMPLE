# Hazra Bari Virtual Dual Temple — Streamlit Cloud

Main file: `JAI_MATA_DI_DUAL_TEMPLE.py`

## Deployment
Upload this folder/repository to GitHub and deploy the main file with Streamlit Community Cloud.

## Login flow
After sign-in, devotees choose:
- 🌺 Maa Durga Mandir
- 🔱 Baba Mahadev Mandir

Both temples use the same theme schedule, account, wallet, cashback, navigation, Panchang, reminders, Japa, Puja, Sankalp, Prasad, Granth, Bhajan, Map, Donation, Diya, Aarti, Search, Dashboard, Advanced Center, Temple Rooms, V15 Center and Admin features.

## Shiva additions
The Shiva Mandir adds Bilva Patra, Aak, Dhatura, Bilva fruit, Ganga Jal, Milk/Curd/Honey/Ghee/Sugar Abhishek, Panchamrit, Bhasma/Vibhuti, Rudraksha, Siddhi/Bhang (symbolic virtual offering), Chandan, Shiva Deep and Rudra Puja.

## Bhog
Baba-er Bhog contains the complete Maa-er Bhog catalog plus Shiva-specific offerings. No Maa-er Bhog dish is removed from the Shiva Mandir.

## Audio
Bell: `97ACG_aLqtM`
Aarti: `BhwOproElxU`

Audio starts only after a user tap to respect browser autoplay restrictions.

## Panchang
Durgapur calculation. Tithi, Nakshatra, Paksha, Sunrise, Sunset, Moonrise and Moonset are shown. Yoga and Karana remain hidden.

Optional Streamlit secrets:
- `ADMIN_EMAILS`
- `SUPABASE_URL`
- `SUPABASE_ANON_KEY`

Do not put private service-role keys in source code.
