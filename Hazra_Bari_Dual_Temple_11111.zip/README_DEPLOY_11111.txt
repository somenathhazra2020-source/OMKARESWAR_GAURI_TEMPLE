Hazra Bari Dual Temple — Streamlit deployment

Files in this ZIP:
- 11111.py — Streamlit app entrypoint
- requirements.txt — app dependencies

Deploy:
1. Upload 11111.py and requirements.txt to the GitHub repository used by the Streamlit app.
2. In Streamlit Community Cloud, set Main file path to 11111.py.
3. In App settings → Secrets, configure:

PANCHANG_API_URL = "https://api.navamsha.in/api/v1/panchang/full"
PANCHANG_API_KEY = "PASTE_YOUR_NEW_NAVAMSHA_API_KEY_HERE"

Use a newly rotated key if the previous key was exposed. Never commit the key to GitHub.
The app uses Durgapur coordinates (23.5204, 87.3119) and IST (UTC+05:30).
Tithi/Paksha/Nakshatra/Yoga/Karana/weekday are fetched from /api/v1/panchang/full.
Sunrise/sunset are fetched from /api/v1/panchang/sun-times.
Moonrise/moonset are fetched from /api/v1/panchang/moon-times.
The timing parser accepts nested response objects and common alternate key names (including generic rise/set fields). If a timing endpoint fails or omits a time, the app displays that value as unavailable and gives a sanitized diagnostic. It never substitutes guessed values.

Database note: this app preserves the source app's existing SQLite database behavior (mandir.db); it does not migrate data to Neon/PostgreSQL.
