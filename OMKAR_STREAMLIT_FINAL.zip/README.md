# Hazra Bari Dual Temple — Streamlit

Main file: `OMKAR.py`

This build fixes the StreamlitDuplicateElementKey error caused by legacy pages rendering the dual temple header twice. The header is idempotent per Streamlit run and resets on each rerun.

Includes `lord_shiva.png` and all existing dual-temple features.
