HAZRA BARI DUAL TEMPLE — ABC.PY
Accurate Durgapur Panchang + Dynamic Mandir Theme

Main file: abc.py

Panchang engine:
- Swiss Ephemeris (pyswisseph)
- Lahiri ayanamsa for Nirayana/Vedic Sun/Moon positions
- Durgapur coordinates: 23.51583 N, 87.30801 E, altitude 100 m
- IST / Asia-Kolkata
- Tithi, Nakshatra, Yoga, Karana, Paksha
- Sunrise, Sunset, Moonrise, Moonset
- Panchang-day convention: the Panchang day begins at sunrise; therefore a
  pre-sunrise Moonrise is not shown as that day's Moonrise.
- Astronomical theme boundary uses the actual astronomical moonrise after
  local midnight, so the weekday theme changes at the daily moonrise.
- Theme light phase: actual sunrise to actual sunset.
- Ashtami override: bright red for Krishna Ashtami / Shukla Ashtami.
- Automatic Streamlit refresh every 60 seconds when streamlit-autorefresh is available.

Validation reference:
Drik Panchang, Durgapur, West Bengal, 8 October 2026.
Reference values: Sunrise 05:35 AM, Sunset 05:21 PM, Moonset 03:47 PM,
Krishna Trayodashi, Purva Phalguni, Shukla Yoga. Swiss Ephemeris produces
Moonrise approximately 04:10 AM on Oct 9 for the Panchang-day calculation;
small lunar-event differences of a few minutes can occur between ephemeris
implementations. The code does not hard-code the reference values.
