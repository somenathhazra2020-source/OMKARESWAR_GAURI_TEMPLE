# HAZRA BARI DUAL TEMPLE — MAHADEV VERSION

Streamlit Cloud package for the Hazra Bari Virtual Mandir with both:
- 🌺 Maa Durga Mandir
- 🔱 Baba Mahadev Mandir

Main file: `MAHADEV.py`

## Shiva-specific corrections
- Shiva Mandir always renders `lord_shiva.png`.
- `Red Hibiscus Chadhawa` is excluded from Shiva Seva.
- `Chunri Seva` is excluded from Shiva Seva.
- Shiva Mandir has `Dhuti-Gamcha Seva` in its place.
- Maa Durga Mandir retains its original Maa-specific Seva catalog.

Deploy on Streamlit Community Cloud with `MAHADEV.py` as the main file.
