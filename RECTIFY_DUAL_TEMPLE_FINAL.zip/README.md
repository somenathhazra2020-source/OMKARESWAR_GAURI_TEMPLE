# Hazra Bari Virtual Mandir — Rectified Aarti Thali Build

Main Streamlit file: `rectify.py`

This build fixes the Aarti Thali so it is a functional Streamlit feature in BOTH Mandirs:
- Maa Durga Mandir: common Aarti items + Red Hibiscus + Chunri
- Baba Mahadev Mandir: common Aarti items + Bilva + Bhasma
- Native Streamlit item selection/checklist
- Begin Aarti and Complete Aarti actions
- Virtual balance deduction and 10% cashback
- Aarti offering recorded in temple history/activity
- Temple-specific Aarti page and deity image preserved

Deploy on Streamlit Cloud with main file path: `rectify.py`.


Final rectification: dual-temple content corrections and functional Aarti Thali for Maa Durga and Baba Mahadev.
